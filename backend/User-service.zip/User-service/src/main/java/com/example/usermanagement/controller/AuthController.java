package com.example.usermanagement.controller;

import com.example.usermanagement.entity.User;
import com.example.usermanagement.enums.Role;
import com.example.usermanagement.repository.UserRepository;
import com.example.usermanagement.service.GoogleAuthService;
import com.example.usermanagement.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class AuthController {

    private final UserRepository repo;
    private final PasswordEncoder encoder;
    private final JwtUtil jwtUtil;
    private final GoogleAuthService googleAuthService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if (repo.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email already exists"));
        }
        if (user.getRole() == null) {
            user.setRole(Role.FARMER);
        }
        user.setPassword(encoder.encode(user.getPassword()));
        user.setProvider("LOCAL");
        user.setEnabled(true);
        repo.save(user);

        String token = jwtUtil.generateToken(user);
        return ResponseEntity.ok(Map.of(
                "message", "Registered successfully",
                "token", token,
                "role", user.getRole().name(),
                "userId", user.getId(),
                "email", user.getEmail()
        ));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String password = payload.get("password");

        User user = repo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!encoder.matches(password, user.getPassword()))
            throw new RuntimeException("Invalid password");

        String token = jwtUtil.generateToken(user);
        return ResponseEntity.ok(Map.of(
                "token", token,
                "role", user.getRole().name(),
                "userId", user.getId(),
                "email", user.getEmail()
        ));
    }

    // ✅ Angular posts { "idToken": "<Google credential>" }
    @PostMapping("/google-login")
    public ResponseEntity<?> googleLogin(@RequestBody Map<String, String> body) {
        try {
            String idToken = body.get("idToken");
            if (idToken == null || idToken.isBlank()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Missing Google token"));
            }
            var result = googleAuthService.verifyAndAuthenticate(idToken);

            if (result.containsKey("status") && result.get("status").equals(202)) {
                return ResponseEntity.status(202).body(result);
            }
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/role-register")
    public ResponseEntity<?> registerRole(@RequestBody Map<String, String> body) {
        try {
            String email = body.get("email");
            String name = body.get("name");
            String roleStr = body.get("role");
            String providerId = body.get("sub");

            if (email == null || name == null || roleStr == null || providerId == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Missing required fields"));
            }

            Role role = Role.valueOf(roleStr.toUpperCase());
            var result = googleAuthService.registerGoogleUser(email, name, role, providerId);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
    @GetMapping("/all")
    public List<User> getAllUsers() {
        return repo.findAll();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        repo.deleteById(id);
        return ResponseEntity.ok(Map.of("message", "User deleted"));
    }

}
