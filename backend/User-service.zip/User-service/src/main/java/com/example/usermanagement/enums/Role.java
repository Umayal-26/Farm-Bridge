package com.example.usermanagement.enums;

public enum Role {
	 	FARMER,
	    DEALER,
	    ADMIN
}
